<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateScheduledMentenancesSentTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('scheduled_maintenance_sent', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('subscribes_id');
            $table->string('email');
            $table->integer('mentenances_id');
            $table->timestamps();
            $table->softDeletes();
        });

        Schema::table('scheduled_maintenance_sent', function (Blueprint $table) {
            $table->foreign('subscribes_id')->references('id')->on('subscribes');
        });

        Schema::table('scheduled_maintenance_sent', function (Blueprint $table) {
            $table->foreign('schedule_id')->references('id')->on('scheduled_maintenance');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('scheduled_maintenance_sent');
    }
}
